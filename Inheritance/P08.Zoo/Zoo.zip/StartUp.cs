﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var a = new Reptile("a");
            a.Name = "aaaaa";
            System.Console.WriteLine(a.Name);
        }
    }
}